///////////RANDOM\\\\\\\\\\\
client.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client2.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client3.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client4.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client5.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client6.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client7.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client8.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client9.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client10.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client11.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client12.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client13.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client14.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client15.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client16.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client17.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client18.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client19.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client20.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client21.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client22.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client23.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client24.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client25.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client26.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client27.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client28.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client29.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client30.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client31.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client32.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client33.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client34.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client35.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client36.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client37.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client38.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client39.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client40.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client41.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client42.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client43.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client44.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client45.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client46.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client47.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client48.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client49.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client50.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client51.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client52.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client53.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client54.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client55.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client56.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client57.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client58.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client59.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client60.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client61.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client62.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client63.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client64.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client65.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client66.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client67.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client68.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client69.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client70.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client71.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client72.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client73.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client74.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client75.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client76.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client77.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client78.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client79.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client80.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client81.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client82.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client83.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client84.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client85.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client86.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client87.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client88.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client89.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client90.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client91.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client92.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client93.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client94.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client95.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client96.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client97.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client98.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client99.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client100.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client101.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client102.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client103.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client104.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client105.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client106.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client107.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client108.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client109.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client110.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client111.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client112.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client113.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client114.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client115.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client116.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client117.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client118.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client119.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client120.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client121.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client122.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client123.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client124.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

client125.on('message', msg => {
  if (msg.author.id !== myid) return;
  if (msg.content === prefix + "random") {
    let vex = [
      "vex up", "vex2",
      "vex3", "vex4",
      "vex5", "vex6",
      "vex7", "vex8",
      "vex9", "vex10",
      "vex11", "vex12",
      ]
    let count = 0
    let ecount = 0;
    for (let x = 0; x < 9000; x++) {
      msg.channel.send(vex[Math.floor((Math.random() * vex.length))])
    }
  }
})

/////////////VC\\\\\\\\\\\\\\\\\\
client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

client.on("ready", () => {
  const channel = client.channels.cache.get(channelid);
  if (!channel) return console.error("The channel does not exist!");
  channel.join().then(connection => {
    console.log("Successfully connected.");
  }).catch(e => {
    console.error(e);
  });
});  

